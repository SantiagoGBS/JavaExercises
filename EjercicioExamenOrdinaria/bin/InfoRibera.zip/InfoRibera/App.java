package InfoRibera;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		if (args[0].length() > 0) {
			if (args[0].contains("--profesor")) {
				String[] linea;
				int codigoprofe;
				linea = args[0].split("=");
				// linea0 es lo anterior al = del split y lo posterior es el codigo
				codigoprofe = Integer.parseInt(linea[1]);

			}
		}
	}

}
